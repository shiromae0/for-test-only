#ifndef SCENE_H
#define SCENE_H

#include <QWidget>
#include <QPushButton>
#include <QPainter>
// #include "config.h"
class Scene : public QWidget
{
    Q_OBJECT
public:
    explicit Scene(QWidget *parent = nullptr);

    // signals:
};

#endif // SCENE_H
