import pyautogui
import time
from start import find_min_location_and_crop
from PIL import Image

global ans
ans = 0

image_files = [Image.open(f"{i}.png") for i in range(1, 5)]
start_position = find_min_location_and_crop(image_files)

matrix= [
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 5, 1, 1, 3, 3, 3, 1],
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 5, 1, 1, 1, 3, 3, 3, 1, 1],
        [1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 5, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1],
        [1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 5, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 5, 1, 1, 1, 1],
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 5, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1],
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 5, 5, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1],
        [1, 1, 1, 5, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 5],
        [1, 1, 1, 11, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 10, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 3, 3, 1, 1, 1, 5, 1, 5, 5, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 3, 3, 3, 1, 1, 1, 5, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 3, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1]
]

def revise_direction(matrix,i,j):
    global ans
    x,y=i,j
    ans=(matrix[x][y]-11-ans)%4
    pyautogui.press("R",ans)

def belt(matrix,position,i,j):
    time.sleep(3)
    tool_location = pyautogui.locateOnScreen('belt.png')

    if tool_location is not None:
        print(f"工具位置: {tool_location}")

        tool_center = pyautogui.center(tool_location)
        pyautogui.moveTo(tool_center, duration=0.5)
        pyautogui.click()
        revise_direction(matrix,i,j)
        pyautogui.moveTo(position,duration=0.5)
        pyautogui.click()

    else:
        print("工具未找到")





def get_position(matrix,grid_size,start_position):
    for i in range(len(matrix)):
        for j in range(len(matrix[0])):
            if matrix[i][j]==11:
                position=start_position[0]+j*grid_size+grid_size/2,start_position[1]+i*grid_size+grid_size/2
                belt(matrix,position,i,j)

            
        
                
            
get_position(matrix,62.3,start_position)

