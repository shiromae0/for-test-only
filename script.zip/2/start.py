import pyautogui
from PIL import Image
import time

def find_min_location_and_crop(image_files, output_file='cropped_image.png', crop_width=1496, crop_height=935):
    time.sleep(2)  # 等待 2 秒，确保窗口完全显示出来
    # 先截取整个屏幕
    screenshot = pyautogui.screenshot()

    # 初始化最小的 x + y 值
    min_sum = None
    min_location = None
    multiple_min = False

    # 遍历每个图像文件
    for image_file in image_files:
        try:
            location = pyautogui.locateOnScreen(image_file)
            print(f"{image_file}: {location}")

            if location:
                x, y = location.left, location.top
                sum_xy = x + y

                # 如果是第一个找到的图像，或当前图像的 x + y 值更小，则更新最小值
                if min_sum is None or sum_xy < min_sum:
                    min_sum = sum_xy
                    min_location = location
                    multiple_min = False  # 重置为单一最小值
                elif sum_xy == min_sum:
                    # 如果有多个最小值，标记为图像识别错误
                    multiple_min = True
        except pyautogui.ImageNotFoundException:
            print(f"未找到图像: {image_file}")

    if multiple_min:
        print("图像识别错误：存在多个最小的 x + y 值。")
    elif min_location:
        x, y = min_location.left, min_location.top

        # 截取指定区域
        #cropped_region = screenshot.crop((x, y, x + crop_width, y + crop_height))

        # 保存或显示截取的区域
        #cropped_region.save(output_file)
        #cropped_region.show()
        return min_location
    else:
        print("未找到任何指定图像。")
        return None

