import pyautogui
import time
from start import find_min_location_and_crop
from PIL import Image


#start_position=(393,39)

# 使用函数
image_files = [Image.open(f"{i}.png") for i in range(1, 5)]
start_position = find_min_location_and_crop(image_files)


matrix= [
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 5, 1, 1, 3, 3, 3, 1],
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 5, 1, 1, 1, 3, 3, 3, 1, 1],
        [1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 5, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1],
        [1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 5, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 5, 1, 1, 1, 1],
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 5, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1],
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 5, 5, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1],
        [1, 1, 1, 5, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 5],
        [1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 3, 10, 1, 1, 1, 5, 1, 5, 5, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 3, 3, 3, 1, 1, 1, 5, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 3, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1]
]
def miner(matrix,start_position):
    grid_size = 62.3
    time.sleep(3)
    tool_location = pyautogui.locateOnScreen('miner.png')

    if tool_location is not None:
        print(f"工具位置: {tool_location}")

        tool_center = pyautogui.center(tool_location)
        target_position=get_position(matrix,grid_size,start_position)
        pyautogui.moveTo(tool_center, duration=0.5)
        pyautogui.click()

        pyautogui.moveTo(target_position,duration=0.5)
        pyautogui.click()

    else:
        print("工具未找到")

def get_position(matrix,grid_size,start_position):
    for i in range(len(matrix)):
        for j in range(len(matrix[0])):
            if matrix[i][j]==10:
                return (start_position[0]+j*grid_size+grid_size/2,start_position[1]+i*grid_size+grid_size/2)
            
miner(matrix, start_position)

