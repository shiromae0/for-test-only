import pyautogui

# 查找工具栏中与'工具.png'匹配的区域
tool_location = pyautogui.locateOnScreen(r'F:\AI\test2\2\tool.png')

if tool_location is not None:
    print(f"工具位置: {tool_location}")
else:
    print("工具未找到")

if tool_location is not None:
# 计算工具中心的位置
    tool_center = pyautogui.center(tool_location)

    # 目标位置，比如(500, 500)
    target_position = (500, 500)

    # 将鼠标移动到工具位置并按下左键
    pyautogui.moveTo(tool_center, duration=0.5)
    pyautogui.click()

    # 拖动到目标位置并释放左键
    pyautogui.moveTo(target_position, duration=0.5)
    pyautogui.click()
else:
    print("工具未找到，无法拖动")